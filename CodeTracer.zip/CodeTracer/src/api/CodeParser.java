package api;

public class CodeParser {
	private String[] program;

	public CodeParser(String[] program) {
		this.program = program;
	}

	public CodeParser() {
	}

	public Complexity traceProgram() {
		return traceProgram(this.program);
	}

	public Complexity traceProgram(String[] program) {
		// all variables
		int indents; // size of indent in every line
		CodeBlock oldTop;
		Complexity oldTopComplexity;
		String keyword;
		String loopVariable;

		BlockStack a = new BlockStack();
		for (String line : program) {
			indents = indentSize(line);
			while (indents < a.size()) {
				if (indents == 0) {
					// Close file and return the total complexity of stack.top.
					return a.pop().getBlockComplexity();
				} else {
					oldTop = a.pop();
					oldTopComplexity = oldTop.getBlockComplexity();
//					if (oldTopComplexity > new Complexity());
				}
				
				if (line.matches(String.join("|", CodeBlock.BLOCK_TYPES))){
					keyword = keywordOfLine(line);
					switch (keyword) {
					case "for":
						
						a.push(new CodeBlock().setBlockComplexity(new Complexity());)
						break;

					default:
						break;
					}
				}
			}
		}
		return new Complexity();
	}

	private Complexity determineComplexityAtEOL(String line) {
		int n_power = 0;
		int log_power = 0;
		if (n_power > 0) return new Complexity(n_power, 0);
		else if (log_power > 0 )
		return new Complexity();
	}
	
	private String keywordOfLine(String a) {
		for (int i = 0; i < CodeBlock.BLOCK_TYPES.length; i++) {
			String string = CodeBlock.BLOCK_TYPES[i];
			if (a.matches(string)) {
				return string;
			}
		}
		return ""; // should never happen
	}
	
	private int indentSize(String a) {
		char[] b = a.toCharArray();
		int indentSize = 0;
		for (int i = 0; i < b.length; i++) {
			if (b[i] == ' ') {
				indentSize++;
			} else {
				break;
			}
		}
		return indentSize;
	}

	public String[] getProgram() {
		return program;
	}

	public void setProgram(String[] program) {
		this.program = program;
	}

}
