package api;

public class CodeBlock {
	public final static String[] BLOCK_TYPES = { "def", "for", "while", "else", "if", "elif" };
	public final static int DEF = 0;
	public final static int FOR = 1;
	public final static int WHILE = 2;
	public final static int IF = 3;
	public final static int ELIF = 4;
	public final static int ELSE = 5;

	private Complexity blockComplexity;
	private Complexity highestSubComplexity;
	
	private String name;
	private String loopVariable;

	public CodeBlock() {
	}

	public CodeBlock(Complexity bC, Complexity hSC) {
		this.blockComplexity = bC;
		this.highestSubComplexity = hSC;
	}

	public Complexity getBlockComplexity() {
		return blockComplexity;
	}

	public void setBlockComplexity(Complexity blockComplexity) {
		this.blockComplexity = blockComplexity;
	}

	public Complexity getHighestSubComplexity() {
		return highestSubComplexity;
	}

	public void setHighestSubComplexity(Complexity highestSubComplexity) {
		this.highestSubComplexity = highestSubComplexity;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLoopVariable() {
		return loopVariable;
	}

	public void setLoopVariable(String loopVariable) {
		this.loopVariable = loopVariable;
	}
}
