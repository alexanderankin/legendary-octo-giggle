package api;

public class BlockStack extends java.util.Stack<CodeBlock>{
	private static final long serialVersionUID = 768341743941991066L;
	
}
